#!/bin/bash

conda install --yes ipython-notebook matplotlib pandas scipy "$@"
